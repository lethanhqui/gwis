<div class="container home">
    <h2>Hệ Thống Quản Lý Học Sinh</h2>
    <p>Chọn menu <a href="/users">Học Sinh</a>, <a href="/classes">Lớp</a>, <a href="/achievements">Miễn Giảm</a>, <a href="/books">Sách</a> để thêm, xóa, chỉnh sửa dữ liệu.</p>
</div>
