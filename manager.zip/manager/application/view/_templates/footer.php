
    <!-- backlink to repo on GitHub, and affiliate link to Rackspace if you want to support the project -->
    <div class="footer">
    <div class="container">
        <div class="powered-by">
			<div class="col-md-6 col-sm-6 col-xs-12 ft-left">
				<span class="llorix_one_lite_copyright_content">© Copyright 2016.Powered by GWIS</span>
			</div>
			
			<div class="col-md-6 col-sm-6 col-xs-12 ft-right">			
				<ul class="social-icons-footer">
						<li>
							<a href="https://www.facebook.com/Tr%C6%B0%E1%BB%9Dng-PTQT-George-Washington-GWIS-B%C3%8CNH-%C4%90%E1%BB%8ANH-200011737080816/?fref=ts">
								<i class="fa llorix-one-lite-footer-icons fa-facebook transparent-text-dark" aria-hidden="true"></i>
							</a>
						</li>
						<li>
							<a href="#">
								<i class="fa llorix-one-lite-footer-icons fa-instagram transparent-text-dark" aria-hidden="true"></i>
							</a>
						</li>
						<li>
							<a href="#">
								<i class="fa llorix-one-lite-footer-icons fa-envelope transparent-text-dark" aria-hidden="true"></i>
							</a>
						</li>
						<li>
							<a href="#">
								<i class="fa llorix-one-lite-footer-icons fa-youtube transparent-text-dark" aria-hidden="true"></i>
							</a>
						</li>
				</ul>
			</div>	        
    </div>
    </div>
    </div>

    <!-- jQuery, loaded in the recommended protocol-less way -->
    <!-- more http://www.paulirish.com/2010/the-protocol-relative-url/ 
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>-->

    <!-- define the project's URL (to make AJAX calls possible, even when using this in sub-folders etc) -->
    <script>
        var url = "<?php echo URL; ?>";
    </script>

    <!-- our JavaScript -->
    <script src="<?php echo URL; ?>js/application.js"></script>
</body>
</html>
